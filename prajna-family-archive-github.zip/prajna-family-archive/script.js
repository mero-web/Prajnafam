/*
  EDIT PROFIL DI BAGIAN INI:
  - name, realName, nickname, job, age: data White Zone
  - description: deskripsi profil yang tampil di White Zone
  - codeName, tabooWork, affiliation, achievement: data Grey Zone
  - photoUrl: URL GAMBAR LANGSUNG (direct image URL)
  - pinterestUrl: URL halaman pin Pinterest untuk tombol sumber foto
  Tips: URL halaman pin Pinterest biasanya bukan URL gambar langsung. Isi photoUrl dengan direct image URL
  yang bisa dibuka sebagai gambar, dan pinterestUrl dengan link pin sebagai referensi/kredit.
*/
const family = [
 {id:"father",name:"Bapak",role:"Father",realName:"[Isi nama asli]",nickname:"[Isi panggilan]",job:"[Isi pekerjaan]",age:"[Isi umur]",description:"[Tulis deskripsi singkat tentang bapak: karakter, kepribadian, latar belakang, atau hal menarik yang ingin ditampilkan di White Zone.]",codeName:"[Isi code name]",tabooWork:"[Isi pekerjaan tabu]",affiliation:"[Isi afiliasi]",achievement:"[Isi pencapaian]",photoUrl:"",pinterestUrl:""},
 {id:"mother",name:"Ibu",role:"Mother",realName:"[Isi nama asli]",nickname:"[Isi panggilan]",job:"[Isi pekerjaan]",age:"[Isi umur]",description:"[Tulis deskripsi singkat tentang ibu: karakter, kepribadian, latar belakang, atau hal menarik yang ingin ditampilkan di White Zone.]",codeName:"[Isi code name]",tabooWork:"[Isi pekerjaan tabu]",affiliation:"[Isi afiliasi]",achievement:"[Isi pencapaian]",photoUrl:"",pinterestUrl:""},
 ...Array.from({length:8},(_,i)=>({id:"child"+(i+1),name:"Anak "+String(i+1).padStart(2,"0"),role:"Child "+String(i+1).padStart(2,"0"),realName:"[Isi nama asli]",nickname:"[Isi panggilan]",job:"[Isi pekerjaan]",age:"[Isi umur]",description:"[Tulis deskripsi singkat tentang anggota keluarga ini: karakter, kepribadian, minat, atau hal menarik lainnya.]",codeName:"[Isi code name]",tabooWork:"[Isi pekerjaan tabu]",affiliation:"[Isi afiliasi]",achievement:"[Isi pencapaian]",photoUrl:"",pinterestUrl:""}))
];
let activeProfile = null;
const byId = id => document.getElementById(id);
function makeCard(person){
 const button=document.createElement("button");button.className="person-card";button.type="button";
 const portrait=document.createElement("div");portrait.className="portrait";
 if(person.photoUrl){const img=document.createElement("img");img.src=person.photoUrl;img.alt="Photo of "+person.name;img.loading="lazy";img.onerror=()=>{img.remove();portrait.innerHTML='<span class="placeholder">✧</span>'};portrait.appendChild(img)}
 else portrait.innerHTML='<span class="placeholder">✧</span>';
 const meta=document.createElement("div");meta.className="card-meta";
 const role=document.createElement("div");role.className="role";role.textContent=person.role;
 const name=document.createElement("div");name.className="person-name";name.textContent=person.name;
 const call=document.createElement("div");call.className="person-call";call.textContent=person.nickname;
 meta.append(role,name,call);button.append(portrait,meta);button.addEventListener("click",()=>openWhite(person.id));return button;
}
family.filter(p=>p.role==="Father"||p.role==="Mother").forEach(p=>byId("parents").appendChild(makeCard(p)));
family.filter(p=>p.role.startsWith("Child")).forEach(p=>byId("children").appendChild(makeCard(p)));
function openWhite(id){
 activeProfile=family.find(p=>p.id===id);if(!activeProfile)return;const p=activeProfile;
 byId("whiteName").textContent=p.name;byId("whiteRole").textContent=p.role;
 byId("whiteDescription").textContent=p.description||"[Belum ada deskripsi profil.]";
 byId("realName").textContent=p.realName;byId("nickname").textContent=p.nickname;byId("job").textContent=p.job;byId("age").textContent=p.age;
 const photo=byId("whitePhoto");photo.innerHTML="";
 if(p.photoUrl){const img=document.createElement("img");img.src=p.photoUrl;img.alt=p.name;img.onerror=()=>photo.textContent="✧";photo.appendChild(img)}else photo.textContent="✧";
 const source=byId("pinterestLink");source.style.display=p.pinterestUrl?"inline-block":"none";source.onclick=()=>window.open(p.pinterestUrl,"_blank","noopener");
 byId("whiteOverlay").classList.add("open");byId("whiteOverlay").setAttribute("aria-hidden","false");
}
byId("showMore").addEventListener("click",()=>{
 if(!activeProfile)return;const p=activeProfile;
 byId("greyName").textContent=p.name+" — Grey Zone";
 byId("codeName").textContent=p.codeName;byId("tabooWork").textContent=p.tabooWork;byId("affiliation").textContent=p.affiliation;byId("achievement").textContent=p.achievement;
 closeModal("whiteOverlay");byId("greyOverlay").classList.add("open");byId("greyOverlay").setAttribute("aria-hidden","false");
});
function closeModal(id){byId(id).classList.remove("open");byId(id).setAttribute("aria-hidden","true")}
document.querySelectorAll(".overlay").forEach(el=>el.addEventListener("click",e=>{if(e.target===el)closeModal(el.id)}));
document.addEventListener("keydown",e=>{if(e.key==="Escape")document.querySelectorAll(".overlay.open").forEach(el=>closeModal(el.id))});
