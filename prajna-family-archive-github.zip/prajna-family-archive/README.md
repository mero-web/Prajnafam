# Prajna's Family — Private Family Archive

Static website prototype built with HTML, CSS, and vanilla JavaScript.

## Files
- `index.html` — page structure
- `style.css` — black-and-gold styling and responsive layout
- `script.js` — family profiles and White Zone / Grey Zone interactions

## Run locally
Open `index.html` in a browser.

## Publish with GitHub Pages
1. Create a GitHub repository.
2. Upload all four files (`index.html`, `style.css`, `script.js`, `README.md`) to the repository root.
3. In repository **Settings → Pages**, choose the branch (usually `main`) and folder `/ (root)`.
4. Save and wait for GitHub Pages to publish the site.

## Edit family profiles
Open `script.js` and edit the `family` array. White Zone fields: `realName`, `nickname`, `job`, `age`, `description`. Grey Zone fields: `codeName`, `tabooWork`, `affiliation`, `achievement`.

For images, set `photoUrl` to a direct image URL. Set `pinterestUrl` to the Pinterest pin page for the source link. A Pinterest page URL itself may not work as an image `photoUrl`.
